#include <stdio.h>
#include <cs50.h>
#include <math.h>
int main(void)
{
    int a=25;
    int b=10;
    int c=5;
    int d=1;

void floor();
}