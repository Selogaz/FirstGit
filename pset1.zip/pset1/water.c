#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int s;
    printf("Minutes:");
    scanf("%d",&s);
    s=12*s;
    printf("Bottles:%d \n", s);
}