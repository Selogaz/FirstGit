#include <stdio.h>
#include <cs50.h>

int main(void)
{   int n;
    printf("Введите число ступеней в высоту:");
    scanf("%d",&n);
    for (int j=0; j<n;j++)//цикл для вывода # в столбик
    {
        for (int k=n-j-1;k>0;k--)//цикл для отступов слева
        {
            printf(" ");
        }
        for (int i=j+2; i>0;i--)//цикл для создания # в строке
        {
            printf("#");
        }
        printf("\n");
    }
printf("Марио - пидор\n");
}