#include <stdio.h>
#include <cs50.h>
#include <math.h>
int main(void)
{
    int a;
    int b;
    int c;
    int d;
    int e;
    printf("Введите сдачу:");
    scanf(" %d",&a);
b=a/25;
c=(a-b*25)/10;
if (a>25)
{
d=(a-25*b)/5;
}
else
{
d=(a-c*10)/5;
}
e=a%5;
printf("25: %d\n",b);
printf("10: %d\n",c);
printf("5:  %d\n",d);
printf("1:  %d\n",e);
}